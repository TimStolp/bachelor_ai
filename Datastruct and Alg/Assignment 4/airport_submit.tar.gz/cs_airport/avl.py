# Tim Stolp 11848782
#
# Enhances a Binary Sort Tree to an Adelson-Velsky and Landis (AVL) tree.

from bst import BST


class AVL(BST):
    def __init__(self, key_list=[]):
        """Create a new AVL Tree, set its attributes, and insert all the keys in
           the key_list into the AVL."""
        BST.__init__(self, key_list)

    def insert(self, key, value=None):
        """Create a new node for this key and value, and insert it into the AVL
           using the BST insert operation. In addition, it ensures that the AVL
           tree is still balanced after this operation is performed.

           Return the new inserted node, or None if the key and value could not
           be inserted."""
        node = super().insert(key, value)
        if node:
            self.fix_balance(node)
        return node

    def delete(self, key):
        """Remove the Node object containing the key if the key exists in
           the AVL using the BST delete operation. In addition, it ensures that
           the AVL tree is still balanced after this operation is performed.

           Return the node that actually got removed from the AVL, which might
           be successor of the removed key."""
        node = super().delete(key)
        if node:
            parent = node.get_parent()
            while parent:
                balance = self.balance(parent)
                if balance < -1 or balance > 1:
                    self.fix_balance(parent.get_max_height_child())
                parent = parent.get_parent()
        return node

    @staticmethod
    def left_rotate(root):
        """Performs a left rotation of the specified node."""
        pivot = root.get_right_child()

        pivot.update_parent(root.get_parent())
        if root.get_parent():
            if pivot < pivot.get_parent():
                root.get_parent().update_left_child(pivot)
            else:
                root.get_parent().update_right_child(pivot)
        root.update_parent(pivot)
        root.update_right_child(pivot.get_left_child())
        if pivot.get_left_child():
            root.get_right_child().update_parent(root)
        pivot.update_left_child(root)

        while root:
            root.update_height()
            root = root.get_parent()

    @staticmethod
    def right_rotate(root):
        """Performs a right rotation of the specified node."""
        pivot = root.get_left_child()

        pivot.update_parent(root.get_parent())
        if root.get_parent():
            if pivot < pivot.get_parent():
                root.get_parent().update_left_child(pivot)
            else:
                root.get_parent().update_right_child(pivot)
        root.update_parent(pivot)
        root.update_left_child(pivot.get_right_child())
        if pivot.get_right_child():
            root.get_left_child().update_parent(root)
        pivot.update_right_child(root)

        while root:
            root.update_height()
            root = root.get_parent()

    def balance(self, node):
        """Calculates the balance of a node."""
        if node.get_right_child():
            right = node.get_right_child().get_height()
        else:
            right = -1
        if node.get_left_child():
            left = node.get_left_child().get_height()
        else:
            left = -1
        return right - left

    def leftleft(self, node, parent):
        """Performs right rotation and keeps track of root."""
        if self.root == parent:
            self.root = node
        AVL.right_rotate(parent)

    def rightright(self, node, parent):
        """Performs left rotation and keeps track of root."""
        if self.root == parent:
            self.root = node
        AVL.left_rotate(parent)

    def leftright(self, node, parent):
        """Performs left and then right rotation and keeps track of root."""
        if self.root == parent:
            self.root = node.get_right_child()
        AVL.left_rotate(node)
        AVL.right_rotate(parent)

    def rightleft(self, node, parent):
        """Performs right and then left rotation and keeps track of root."""
        if self.root == parent:
            self.root = node.get_left_child()
        AVL.right_rotate(node)
        AVL.left_rotate(parent)

    def fix_balance(self, node):
        """Performs a sequence of rotations to fix the balance of a node and
           all its parent nodes if needed to maintain the AVL property."""
        parent = node.get_parent()

        while parent:
            node_balance = self.balance(node)
            parent_balance = self.balance(parent)

            if parent_balance < -1 and node_balance < 0:
                self.leftleft(node, parent)

            elif parent_balance > 1 and node_balance > 0:
                self.rightright(node, parent)

            elif parent_balance < -1 and node_balance > 0:
                self.leftright(node, parent)

            elif parent_balance > 1 and node_balance < 0:
                self.rightleft(node, parent)

            node = parent
            parent = node.get_parent()

        self.current = self.root
