# Tim Stolp 11848782
#
# Creates airport class which schedules flights using an AVL tree.

import argparse

from avl import AVL


class Airport(AVL):
    def __init__(self, wait_time=300000, simple=False):
        """Creates a new Airport instance and sets its basic attributes."""
        AVL.__init__(self)
        
        self.wait_time = wait_time
        self.simple = simple
    
    def find_conflict(self, time):
        """Return the first node in the tree that conflicts with the specified
           time and wait_time attribute set for the Airport.
           
           Returns None if no such conflict is found."""
        node_list = super().in_order_traversal()
        for node in node_list:
            flight = node.get_key()
            if flight - self.wait_time < time < flight + self.wait_time:
                return node
        return None

    def bounded_insert(self, time, tailnumber):
        """Inserts an airplane with a time and tailnumber into the schedule.
           If there is a conflict in schedule times then insert airplane at next possible moment,
           or do not insert if simple flag is set to true.

           Returns the node if successfully inserted and None otherwise."""
        if self.simple:
            if self.find_conflict(time):
                return None
            else:
                node = super().insert(time, tailnumber)
                return node
        else:
            while True:
                conflict = self.find_conflict(time)
                if conflict:
                    time = conflict.get_key() + self.wait_time
                else:
                    node = super().insert(time, tailnumber)
                    return node

    def __str__(self):
        """Return the airplanes in the schedule in sorted order."""
        return " ".join([str(flight) for flight in super().in_order_traversal()])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Sort a list of elements.')
    parser.add_argument('elements', nargs='+',
                    help='The elements of a list')
    parser.add_argument("-t", "--timestep", type=int,
                    help="set the minimum timestep (default=300000)", default=300000)
    parser.add_argument("-s", "--simple", action="store_true",
                    help="either become simple or not")
    args = parser.parse_args()

    cs_airport = Airport(args.timestep, args.simple)
    for elem in args.elements:
        try:
            s = elem.split('/')
            time, tail = int(s[0]), s[1]
            cs_airport.bounded_insert(time, tail)
        except (ValueError, IndexError):
            print("Invalid airplane format: "+elem)
    
    print(cs_airport)
