#ifndef DATA
#define DATA

typedef double data_t;

#endif
