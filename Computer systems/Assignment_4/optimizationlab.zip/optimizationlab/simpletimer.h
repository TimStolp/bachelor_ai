/*
 * simpletimer.h
 */
void timer_start(struct timeval* stv);
double timer_end(struct timeval stv);
